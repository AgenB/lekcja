import Vector from "./vector.js";
import {CTX } from './globals.js'


class GameObject {
	constructor(x = 0, y = 0, speed = 0, direction) {
		this.stopMove = false;
		this.position = new Vector(x, y);
		this.velocity = new Vector(1, 1);
		this.velocity.setLength(speed);
		this.velocity.setAngle(direction);
	}

	// updatePosition() {
	// 	this.stop ? this.velocity.setLength(0) : null;
	// 	this.position.addVector(this.velocity);
	// }

	angleToVector(GameObj2) {
		return Math.atan2(
			GameObj2.position.getY() - this.position.getY(),
			GameObj2.position.getX() - this.position.getX()
		);
	}

	drawGameObjectImage(image, x, y, w, h, degrees=0) {
		CTX.save();
		CTX.translate(x + w / 2, y + h / 2);
		//CTX.scale(0.5,0.5);
		CTX.rotate((degrees * Math.PI) / 180.0);
		CTX.translate(-x - w / 2, -y - h / 2);
		CTX.drawImage(image, x, y, w, h);
		CTX.beginPath();
		CTX.strokeStyle = "#00FF00";
		CTX.strokeRect(x, y, w, h);
		CTX.restore();
		CTX.closePath();
		CTX.strokeStyle = "#FF0000";
		CTX.beginPath();
		CTX.strokeRect(x, y, w, h);
		CTX.closePath();
	}
}

export default GameObject;