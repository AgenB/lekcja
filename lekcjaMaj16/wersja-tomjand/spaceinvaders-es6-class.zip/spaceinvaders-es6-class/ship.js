import GameObject from "./gameObject.js";
import { clamp} from "./tools.js";
import { IMAGES, GAME, STATE } from './globals.js'

class Ship extends GameObject{
	constructor(x = 0, y = 0, speed, direction) {
		super(x, y, speed, direction);
		this.velocity.setLength(3);
		this.velocity.setAngle(- Math.PI);
		this.img = new Image();
		this.img.src = `${IMAGES}spaceShips_004.png`;
		this.scale = 0.5;
		this.width = this.img.width * this.scale
		this.height = this.img.height * this.scale
		this.centerWidth = (GAME.WIDTH / 2 ) - this.width/2
		this.posHeight = GAME.HEIGHT - this.height - 25
		this.minStage = 0 - GAME.WIDTH / 2 + this.width / 2;
		this.maxStage = GAME.WIDTH - GAME.WIDTH / 2 - this.width / 2;
	}

	draw(x = 0, y = 0 ) {
		this.drawGameObjectImage(
			this.img,
			this.centerWidth + x,
			this.posHeight + y,
			this.width,
			this.height,
			this.rotate
		);
	}

	
	update() {
		if (STATE.leftPressed) {
			this.position.addVector(this.velocity);
		  }
		if (STATE.rightPressed) {
			this.position.diffVector(this.velocity);
		  }
		this.position.x = clamp(this.position.x, this.minStage, this.maxStage);
		this.draw(this.position.x, this.position.y);
	}
}

export default Ship