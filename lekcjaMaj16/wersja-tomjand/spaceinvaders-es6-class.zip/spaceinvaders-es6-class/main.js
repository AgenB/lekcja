import { getRandom } from './tools.js';
import {STATE } from './globals.js'
import Level from './level.js'
import Ship from './ship.js'
import Missile from './missile.js'
import Button from './ui.js';
import Control from './controls.js';

class Game {
	constructor() {
		this.level = new Level();
		this.ship = new Ship(10, 20, 0, Math.PI / 2);
		this.missile =  new Missile(10, 20, 0, Math.PI / 2);;
		this.control = new Control(document.body);
		this.countRequestFrame;
		this.loop = () => {
			const currentTime = Date.now ();
			const dt = (currentTime - STATE.lastTime) / 1000;
			this.update();
			this.countRequestFrame = requestAnimationFrame(this.loop);
			STATE.lastTime = currentTime;
		};
	}

	reset() {
		
	}

	win() {
		
	}

	gameOver() {
		
	}

	shoot() {
		if (STATE.spacePressed) {
			this.missile = new Missile(10, 20, 0, Math.PI / 2);
			STATE.shoot = false;
			//this.missile.update()
			
		}
		this.missile.update()
	}

	update() {
		this.level.drawBackgroundImg()
		this.ship.update()
		this.shoot()
		this.control.keyCheck()
	}
}

(function () {
	const myGame = new Game();
	myGame.loop();
})();