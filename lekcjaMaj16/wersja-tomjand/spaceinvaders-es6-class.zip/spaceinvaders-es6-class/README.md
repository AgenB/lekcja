spaceInvaders-es6-class
