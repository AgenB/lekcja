const game = document.querySelector('.game');
export const CVS = document.querySelector("#canvas");
export const CTX = CVS.getContext("2d");
CVS.width = 500;
CVS.height = 350;

CTX.font = "16px Arial";
export const IMAGES = "./images/";

export const KEY = {
	LEFT: 37,
	RIGHT: 39,
	SPACE: 32
};

export const GAME = {
	WIDTH: CVS.width,
	HEIGHT: CVS.height,
	PLAYER_WIDTH: 20,
	LASER_MAX_SPEED: 150,
};

export const ENEMY_ARMY_SETUP = {
	HORIZONTAL_PADDING: 80,
	VERTICAL_PADDING: 50,
	VERTICAL_SPACING: 70,
	PER_ROW: 10,
	ROWS: 3,
	ENEMY_COUNT_DOWN: 20
  };

export const STATE = {
	lastTime: Date.now(),
	leftPressed: false,
	rightPressed: false,
	spacePressed: false,
	shoot: true,
	playerX: 0,
	playerY: 0,
	playerMissiles: [],
	enemies: [],
	enemyMissiles: [],
	playerMissilesValue: 20,  
	score: 0,
	gameOver: false,
};

