import { CTX,IMAGES } from './globals.js'
import {
	inRange
} from "./tools.js";
class Button {
	constructor(x = 0, y = 0, w = 0, h = 0, color = "#FF0000", text = "BUM") {
		
		
		this.y = y;
		this.w = w;
		this.h = h;
		x === "centerX" ? (this.x = (this.CVS.width - this.w) / 2) : (this.x = x);
		this.color = color;
		this.text = text;
		this.r = {
			x,
			y,
			w,
			h
		};
	}

	collisionRectPoint(mouse) {
		return (
			inRange(mouse.x, this.x, this.x + this.w) &&
			inRange(mouse.y, this.y, this.y + this.h)
		);
	}

	draw(x, y) {
		this.ctx.beginPath();
		this.ctx.fillStyle = this.color;
		this.ctx.fillRect(this.x, this.y, this.w, this.h);
		this.ctx.fillStyle = "#FFFFFF";
		this.ctx.textAlign = "center";
		this.ctx.fillText(this.text, this.CVS.width / 2, this.CVS.height / 2);
		this.ctx.closePath();
	}

	setHoverColor() {
		this.color = "blue";
	}

	setPirmaryColor() {
		this.color = "red";
	}

}

export default Button;