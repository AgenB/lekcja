import { CTX,IMAGES } from './globals.js'

class Level{
	constructor() {
		this.img = new Image();
		this.img.src = `${IMAGES}background-blue.png`;
		this.isCreatePtrn = false;
		
	}

	drawBackgroundImg() {
		let ptrn = CTX.createPattern( this.img, 'repeat'); 
		CTX.fillStyle = ptrn;
		CTX.fillRect(0, 0, canvas.width, canvas.height); 
	}
}

export default Level

