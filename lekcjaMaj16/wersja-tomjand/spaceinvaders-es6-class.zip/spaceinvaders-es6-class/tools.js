
const getRandom = (max,min) => Math.floor(Math.random() * (max - min) + min);

const objFromImg = (img) => ({w:img.width,h:img.height})

const rangeIntersect = ( min0, max0, min1, max1 ) => Math.max(min0,max0) >= Math.min(min1,max1) && Math.min(min0,max0)<=Math.max(min1,max1);

const inRange = (value, min, max) =>
  value >= Math.min(min, max) && value <= Math.max(min, max);

const clamp = (v, min, max) => {
	if (v < min) {
	  return min;
	} else if (v > max) {
	  return max;
	} else {
	  return v;
	}
  }
  
//const rectsIntersect = (r0, r1) => rangeIntersect(r0.x, r0.x+r0.w, r1.x, r1.x+r1.w) && rangeIntersect(r0.y, r0.y+r0.h, r1.y, r1.y+r1.h)

const rectsIntersect = (r1, r2) => {
	return !(
	  r2.left > r1.right ||
	  r2.right < r1.left ||
	  r2.top > r1.bottom ||
	  r2.bottom < r1.top
	);
  }

export { getRandom, rectsIntersect, objFromImg, rangeIntersect, inRange, clamp}