import GameObject from "./gameObject.js";
import { IMAGES, GAME, STATE } from './globals.js'

class Missile extends GameObject { 
	constructor(x = 0, y = 0, speed, direction) {
		super(x, y, speed, direction);
		this.velocity.setLength(3);
		this.velocity.setAngle(- Math.PI/2);
		this.img = new Image();
		this.img.src = `${IMAGES}spaceMissiles_040.png`;
		this.scale = 0.5;
		this.width = this.img.width * this.scale
		this.height = this.img.height * this.scale
		this.centerWidth = (GAME.WIDTH / 2 ) - this.width/2
		this.posHeight = GAME.HEIGHT - this.height - 25
		this.minStage = 0 - GAME.WIDTH / 2 + this.width / 2;
		this.maxStage = GAME.WIDTH - GAME.WIDTH / 2 - this.width / 2;
	}

	draw(x = 10, y = 10 ) {
		this.drawGameObjectImage(
			this.img,
			this.centerWidth + x,
			this.posHeight + y,
			this.width,
			this.height,
			this.rotate
		);
	}

	
	update() {
		if (STATE.spacePressed) {
			
			STATE.shoot = false;
			console.log("object");
		  }
		  this.position.addVector(this.velocity);
		//this.position.x = clamp(this.position.x, this.minStage, this.maxStage);
		this.draw(this.position.x, this.position.y);
	}

}

export default Missile