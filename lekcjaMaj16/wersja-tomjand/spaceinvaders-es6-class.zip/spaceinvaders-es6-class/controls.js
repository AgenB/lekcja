import {KEY, CVS, STATE} from './globals.js'
class Control {
	constructor(documentGame) {
		this.mouse = {
			x: 0,
			y: 0,
		};
		this.inputs = false;
		this.onBtn = false;

		

		documentGame.addEventListener('keydown', (event) => {
			if (event.keyCode === KEY.LEFT) {
				STATE.leftPressed = true;
			  } else if (event.keyCode === KEY.RIGHT) {
				STATE.rightPressed = true;
			  } else if (event.keyCode === KEY.SPACE) {
				STATE.spacePressed = true;				
			  }
		});

		documentGame.addEventListener('keyup',(event) => {
			if (event.keyCode === KEY.LEFT) {
				STATE.leftPressed = false;
			  } else if (event.keyCode === KEY.RIGHT) {
				STATE.rightPressed = false;
			} else if (event.keyCode === KEY.SPACE) {
				STATE.spacePressed = false;
			  }
		} );

		documentGame.addEventListener('mousemove', event => {
			this.mouse = this.getCanvasMousePos(CVS, event);
			this.onBtn = false;
		});

		documentGame.addEventListener('mouseenter', event => {
			this.mouse = this.getCanvasMousePos(CVS, event);
			this.onBtn = false;
		});

		documentGame.addEventListener('click', event => {
			this.mouse = this.getCanvasMousePos(CVS, event);
			this.onBtn = true;
		});
	}

	getCanvasMousePos(canvas, evt) {
		var rect = canvas.getBoundingClientRect();
		return {
			x: (evt.clientX - rect.left) / (rect.right - rect.left) * canvas.width,
			y: (evt.clientY - rect.top) / (rect.bottom - rect.top) * canvas.height,
		};
	}

	keyCheck() {
		return this.inputs;
	}


	getMouseCoords() {
		return this.mouse;
	}

	getOnBtn() {
		return this.onBtn;
	}
}

export default Control;